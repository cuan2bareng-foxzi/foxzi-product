/*
========================================================
📜 LICENSE AGREEMENT – KODE WEB
========================================================
Hak Cipta © [2025] [LIVIAA / BRAND]

🔐 Lisensi Penggunaan:
Kode web ini hanya diperbolehkan untuk:
✔ Penggunaan pribadi / internal
✔ Kebutuhan proyek resmi yang telah mendapatkan izin langsung
❌ Tidak boleh diperjualbelikan ulang
❌ Tidak boleh dibagikan tanpa izin
❌ Tidak boleh di-copy, di-reupload, atau dipakai untuk kepentingan komersial tanpa perjanjian resmi

💼 Penggunaan Komersial:
Penggunaan untuk proyek bisnis, penjualan layanan, atau penyewaan wajib memiliki
perjanjian lisensi resmi dari pemilik. Hubungi: Liviaa

⚠ Modifikasi Kode:
Pengguna diperbolehkan memodifikasi kode untuk kebutuhan internal,
namun tetap tunduk pada aturan lisensi. Larangan menghapus bagian
teks lisensi, watermark, atau identitas pemilik.

🚫 Pelanggaran:
Segala bentuk pelanggaran akan dikenakan tindakan hukum sesuai
UU Hak Cipta dan ketentuan pelindungan digital.

========================================================
Dengan menggunakan kode ini, Anda dianggap sudah membaca,
memahami, dan menyetujui seluruh isi lisensi.
========================================================
*/
